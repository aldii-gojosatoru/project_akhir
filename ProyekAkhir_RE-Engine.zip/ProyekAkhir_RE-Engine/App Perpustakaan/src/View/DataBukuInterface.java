package View;

import Main.Koneksi;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
/**
 * The DataBukuInterface interface provides the necessary methods to manage book data
 * in the library application.
 * 
 * This interface defines several abstract methods and also provides default methods to
 * print library information and static methods to initialize the database connection.
 */

public interface DataBukuInterface {
    /**
     * Sets the table model for displaying book data.
     */
    
    void setTabelModel();
    /**
     * Loads book data from the database and displays it in the table.
     */
    
    void loadData();
    /**
     * Searches for book data based on the keyword entered by the user.
     */

    void searchData();
    /**
     * Sets the renderer for the table to display book images.
     */

    void setTableRenderer();
    /**
     * Retrieves book data from the database with specified limits and inserts it into the table model.
     *
     * @param startIndex the starting index for the data to be retrieved
     * @param entriesPage the number of data entries per page
     * @param model the table model to hold the retrieved data
     */

    void getData(int startIndex, int entriesPage, DefaultTableModel model);
    
     /**
     * Prints information about the library.
     * This is a default method that can be overridden by the implementing class.
     */

    default void printLibraryInfo() {
        System.out.println("Perpustakaan ABC - Menyediakan berbagai macam buku untuk masyarakat.");
    }
    
    /**
     * Initializes the connection to the library database.
     * This is a static method that can be called without creating an object of the implementing class.
     */


    static void initializeDatabaseConnection() {
        System.out.println("Inisialisasi koneksi ke database perpustakaan...");
        // Contoh implementasi inisialisasi koneksi database
        Connection conn = Koneksi.getConnection();
        if (conn != null) {
            System.out.println("Koneksi database berhasil.");
        } else {
            System.out.println("Gagal menghubungkan ke database.");
        }
    }
}
